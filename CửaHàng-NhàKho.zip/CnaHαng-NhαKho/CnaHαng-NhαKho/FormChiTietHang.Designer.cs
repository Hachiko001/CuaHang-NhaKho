﻿namespace CửaHàng_NhàKho
{
    partial class chitiethangForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(chitiethangForm));
            this.tenhangLbl = new System.Windows.Forms.Label();
            this.tenBox = new System.Windows.Forms.TextBox();
            this.maBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nhasxBox = new System.Windows.Forms.TextBox();
            this.nhasxLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.giabanBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.anhhangPic = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.menhgiabanBox = new System.Windows.Forms.TextBox();
            this.menhgianhapBox = new System.Windows.Forms.TextBox();
            this.gianhapBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.soluongBox = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.themhinhPic = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.motaBox = new System.Windows.Forms.TextBox();
            this.luuBtn = new System.Windows.Forms.Button();
            this.huyBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.anhhangPic)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluongBox)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.themhinhPic)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tenhangLbl
            // 
            this.tenhangLbl.AutoSize = true;
            this.tenhangLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tenhangLbl.Location = new System.Drawing.Point(6, 31);
            this.tenhangLbl.Name = "tenhangLbl";
            this.tenhangLbl.Size = new System.Drawing.Size(126, 22);
            this.tenhangLbl.TabIndex = 0;
            this.tenhangLbl.Text = "Tên mặt hàng:";
            // 
            // tenBox
            // 
            this.tenBox.Location = new System.Drawing.Point(133, 31);
            this.tenBox.Name = "tenBox";
            this.tenBox.Size = new System.Drawing.Size(169, 23);
            this.tenBox.TabIndex = 1;
            this.tenBox.TextChanged += new System.EventHandler(this.tenBox_TextChanged);
            // 
            // maBox
            // 
            this.maBox.Location = new System.Drawing.Point(133, 68);
            this.maBox.Name = "maBox";
            this.maBox.Size = new System.Drawing.Size(169, 23);
            this.maBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(6, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mã mặt hàng:";
            // 
            // nhasxBox
            // 
            this.nhasxBox.Location = new System.Drawing.Point(133, 32);
            this.nhasxBox.Name = "nhasxBox";
            this.nhasxBox.Size = new System.Drawing.Size(169, 20);
            this.nhasxBox.TabIndex = 7;
            // 
            // nhasxLbl
            // 
            this.nhasxLbl.AutoSize = true;
            this.nhasxLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.nhasxLbl.Location = new System.Drawing.Point(6, 30);
            this.nhasxLbl.Name = "nhasxLbl";
            this.nhasxLbl.Size = new System.Drawing.Size(121, 22);
            this.nhasxLbl.TabIndex = 6;
            this.nhasxLbl.Text = "Nhà sản xuất:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(19, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 22);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nhập:";
            // 
            // giabanBox
            // 
            this.giabanBox.Location = new System.Drawing.Point(83, 55);
            this.giabanBox.Name = "giabanBox";
            this.giabanBox.Size = new System.Drawing.Size(147, 23);
            this.giabanBox.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(19, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 22);
            this.label3.TabIndex = 10;
            this.label3.Text = "Bán: ";
            // 
            // anhhangPic
            // 
            this.anhhangPic.Location = new System.Drawing.Point(74, 22);
            this.anhhangPic.Name = "anhhangPic";
            this.anhhangPic.Size = new System.Drawing.Size(202, 174);
            this.anhhangPic.TabIndex = 12;
            this.anhhangPic.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.menhgiabanBox);
            this.groupBox1.Controls.Add(this.menhgianhapBox);
            this.groupBox1.Controls.Add(this.gianhapBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.giabanBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.Location = new System.Drawing.Point(25, 227);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 102);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Giá:";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // menhgiabanBox
            // 
            this.menhgiabanBox.AutoCompleteCustomSource.AddRange(new string[] {
            "USD",
            "Euro",
            "VNĐ"});
            this.menhgiabanBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.menhgiabanBox.Location = new System.Drawing.Point(236, 55);
            this.menhgiabanBox.Name = "menhgiabanBox";
            this.menhgiabanBox.Size = new System.Drawing.Size(66, 23);
            this.menhgiabanBox.TabIndex = 19;
            // 
            // menhgianhapBox
            // 
            this.menhgianhapBox.AutoCompleteCustomSource.AddRange(new string[] {
            "USD",
            "Euro",
            "VNĐ"});
            this.menhgianhapBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.menhgianhapBox.Location = new System.Drawing.Point(236, 19);
            this.menhgianhapBox.Name = "menhgianhapBox";
            this.menhgianhapBox.Size = new System.Drawing.Size(66, 23);
            this.menhgianhapBox.TabIndex = 18;
            // 
            // gianhapBox
            // 
            this.gianhapBox.Location = new System.Drawing.Point(83, 20);
            this.gianhapBox.Name = "gianhapBox";
            this.gianhapBox.Size = new System.Drawing.Size(147, 23);
            this.gianhapBox.TabIndex = 15;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tenhangLbl);
            this.groupBox2.Controls.Add(this.tenBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.maBox);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.Location = new System.Drawing.Point(25, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 110);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tên và mã hàng:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.soluongBox);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.nhasxLbl);
            this.groupBox3.Controls.Add(this.nhasxBox);
            this.groupBox3.Location = new System.Drawing.Point(25, 125);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 96);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Xuất xứ: ";
            // 
            // soluongBox
            // 
            this.soluongBox.Location = new System.Drawing.Point(133, 64);
            this.soluongBox.Name = "soluongBox";
            this.soluongBox.Size = new System.Drawing.Size(69, 20);
            this.soluongBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(6, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 22);
            this.label4.TabIndex = 8;
            this.label4.Text = "Số lượng:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(944, 579);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.themhinhPic);
            this.groupBox4.Controls.Add(this.anhhangPic);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox4.Location = new System.Drawing.Point(358, 9);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(291, 212);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Hình ảnh:";
            // 
            // themhinhPic
            // 
            this.themhinhPic.Image = ((System.Drawing.Image)(resources.GetObject("themhinhPic.Image")));
            this.themhinhPic.InitialImage = null;
            this.themhinhPic.Location = new System.Drawing.Point(22, 31);
            this.themhinhPic.Name = "themhinhPic";
            this.themhinhPic.Size = new System.Drawing.Size(39, 39);
            this.themhinhPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.themhinhPic.TabIndex = 13;
            this.themhinhPic.TabStop = false;
            this.themhinhPic.Click += new System.EventHandler(this.themhinhPic_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.motaBox);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox5.Location = new System.Drawing.Point(358, 227);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(291, 100);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Mô tả: ";
            // 
            // motaBox
            // 
            this.motaBox.Location = new System.Drawing.Point(22, 29);
            this.motaBox.Multiline = true;
            this.motaBox.Name = "motaBox";
            this.motaBox.Size = new System.Drawing.Size(254, 50);
            this.motaBox.TabIndex = 0;
            // 
            // luuBtn
            // 
            this.luuBtn.Location = new System.Drawing.Point(564, 335);
            this.luuBtn.Name = "luuBtn";
            this.luuBtn.Size = new System.Drawing.Size(85, 27);
            this.luuBtn.TabIndex = 20;
            this.luuBtn.Text = "Thêm";
            this.luuBtn.UseVisualStyleBackColor = true;
            this.luuBtn.Click += new System.EventHandler(this.luuBtn_Click);
            // 
            // huyBtn
            // 
            this.huyBtn.Location = new System.Drawing.Point(447, 335);
            this.huyBtn.Name = "huyBtn";
            this.huyBtn.Size = new System.Drawing.Size(85, 27);
            this.huyBtn.TabIndex = 21;
            this.huyBtn.Text = "Hủy";
            this.huyBtn.UseVisualStyleBackColor = true;
            this.huyBtn.Click += new System.EventHandler(this.huyBtn_Click);
            // 
            // chitiethangForm
            // 
            this.AcceptButton = this.luuBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 374);
            this.Controls.Add(this.huyBtn);
            this.Controls.Add(this.luuBtn);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "chitiethangForm";
            this.Text = "Chi tiết hàng";
            this.Load += new System.EventHandler(this.FormChiTietHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.anhhangPic)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluongBox)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.themhinhPic)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tenhangLbl;
        private System.Windows.Forms.TextBox tenBox;
        private System.Windows.Forms.TextBox maBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nhasxBox;
        private System.Windows.Forms.Label nhasxLbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox giabanBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox anhhangPic;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox menhgiabanBox;
        private System.Windows.Forms.TextBox menhgianhapBox;
        private System.Windows.Forms.TextBox gianhapBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox themhinhPic;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox motaBox;
        private System.Windows.Forms.Button luuBtn;
        private System.Windows.Forms.Button huyBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown soluongBox;
    }
}